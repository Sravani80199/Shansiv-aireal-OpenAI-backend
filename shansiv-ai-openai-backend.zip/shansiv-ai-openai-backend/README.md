# Shansiv AI OpenAI Backend

A small FastAPI backend that connects a website to the OpenAI Responses API.

## Deploy on Render

1. Push these files to a GitHub repository.
2. In Render, create a new **Web Service** and connect this repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Add environment variables in Render:
   - `OPENAI_API_KEY` = your secret API key (never put it in GitHub or browser code)
   - `OPENAI_MODEL` = `gpt-6-luna` (change only to a model available to your API project)
   - `FRONTEND_ORIGINS` = your exact Netlify website URL
6. Deploy. Test `https://YOUR-RENDER-SERVICE.onrender.com/health`.

## Chat endpoint

`POST /api/chat`

Request:
```json
{
  "message": "Hello Shansiv AI",
  "history": []
}
```

Response:
```json
{
  "reply": "Hello! ...",
  "model": "gpt-6-luna"
}
```

## Important

- OpenAI API usage may incur charges. ChatGPT subscriptions do not include API usage.
- Add billing/credits to your OpenAI API project if requests fail for billing reasons.
- Keep `OPENAI_API_KEY` only in the backend host's secret/environment-variable settings.
- The website frontend must be updated to send chat messages to this backend URL. Deploying this backend alone does not automatically change the existing Netlify website.
