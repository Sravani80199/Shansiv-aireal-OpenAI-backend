import os
from typing import List, Literal
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from openai import OpenAI, OpenAIError

APP_NAME = "Shansiv AI API"
MODEL = os.getenv("OPENAI_MODEL", "gpt-6-luna")
API_KEY = os.getenv("OPENAI_API_KEY")

app = FastAPI(title=APP_NAME, version="1.0.0")

# Set FRONTEND_ORIGINS to your Netlify site URL before production.
# Example: https://your-site-name.netlify.app
origins = [
    origin.strip()
    for origin in os.getenv("FRONTEND_ORIGINS", "*").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)

class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    history: List[ChatMessage] = Field(default_factory=list, max_length=20)

class ChatResponse(BaseModel):
    reply: str
    model: str

@app.get("/")
def home():
    return {"name": APP_NAME, "status": "running", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok", "api_key_configured": bool(API_KEY)}

@app.post("/api/chat", response_model=ChatResponse)
def chat(body: ChatRequest):
    if not API_KEY:
        raise HTTPException(
            status_code=503,
            detail="Server is missing OPENAI_API_KEY. Add it in your hosting environment variables."
        )

    client = OpenAI(api_key=API_KEY)
    conversation = [
        {"role": item.role, "content": item.content}
        for item in body.history
    ]
    conversation.append({"role": "user", "content": body.message})

    try:
        response = client.responses.create(
            model=MODEL,
            instructions=(
                "You are Shansiv AI, a helpful, accurate, friendly assistant. "
                "Explain clearly, admit uncertainty, and never claim to have performed "
                "actions you cannot perform."
            ),
            input=conversation,
            max_output_tokens=800,
        )
        reply = response.output_text
        if not reply:
            raise HTTPException(status_code=502, detail="The AI returned an empty response.")
        return ChatResponse(reply=reply, model=MODEL)
    except OpenAIError as exc:
        # Do not expose secrets or raw provider details to website visitors.
        raise HTTPException(
            status_code=502,
            detail="The AI provider request failed. Check API billing, key permissions, and model access."
        ) from exc
